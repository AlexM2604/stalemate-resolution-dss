#  Copyright (c) 2022. Harold Van Heukelum

from .algorithm import aggregate_max

__version__ = '1.0.0'
__author__ = 'HJvH'
