# API connection to Tetra

This package contains the module to send to and receive data from the Tetra API. It will build the XMl for you and
returns the data as a list. Please note that credentials are needed for the API and these credentials are not free 
to share.

# Contact

Please contact Harold van Heukelum at harold.van.heukelum@boskalis.nl for anything related to this repository.

# Closing remarks

The use, duplication or distribution of this code is not allowed without explicit permission of
the author. Copyright (c) Harold van Heukelum, 2022
